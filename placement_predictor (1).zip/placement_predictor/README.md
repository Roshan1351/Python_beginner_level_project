# Placement Chance Predictor (AI Mini Project)
TYBSc CS Sem V - Introduction to AI | Supervised learning (classification) with Logistic Regression.

- `placement_data.xlsx` - dataset of 50 students (sample data; replace with real data, same headers)
- `app.py` - reads the Excel, trains the model on it, serves the web UI
- `templates/index.html` - the UI

Run: `pip install -r requirements.txt` then `python app.py` and open http://127.0.0.1:5000

The prediction comes only from the Excel data (no hard-coded rules). Suggestions compare the student with
placed students in the same dataset. Edit the Excel and restart to change results.
