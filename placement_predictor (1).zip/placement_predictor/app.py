import pandas as pd
from flask import Flask, render_template, request
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

app = Flask(__name__)
YN = [(0, "No"), (1, "Yes")]
SCALE = [(i, str(i)) for i in range(1, 6)]
STACKS = ["MERN Stack", "MEAN Stack", "Java Full Stack", ".NET Full Stack", "Python Full Stack", "PHP / Laravel", "Backend Developer",
          "Frontend Developer", "SQL / Data Analyst", "Data Science / ML", "Android / Flutter", "DevOps / Cloud", "Testing / QA"]

def F(name, label, sec, kind="num", lo=0, hi=5, dv=0, step=1, hb=True, opts=None, tip=""):
    if kind == "yn": opts = YN
    if kind == "scale": opts = SCALE; dv = 3
    return dict(name=name, label=label, sec=sec, kind=kind, lo=lo, hi=hi, dv=dv, step=step, hb=hb, opts=opts, tip=tip)

A, C, P, S, O = "Academics", "Coding Profiles & DSA", "Projects & Experience", "Skills & Soft Skills", "Online Presence & Preparation (Yes / No)"
FIELDS = [
    F("cgpa", "CGPA (out of 10)", A, lo=5, hi=10, dv=7.5, step=0.01, tip="Keep CGPA above 7 - many companies use it as a cut-off."),
    F("hsc_percent", "12th / Diploma percentage", A, lo=40, hi=100, dv=70, tip="Cannot change now - balance it with strong skills and projects."),
    F("college_tier", "College tier", A, kind="sel", dv=2, opts=[(1, "Tier 1 (IIT / NIT / IIIT)"), (2, "Tier 2"), (3, "Tier 3")], hb=False, tip="Off-campus drives and referrals help beat a tier gap."),
    F("backlogs", "Active backlogs", A, hi=10, hb=False, tip="Clear all backlogs - many companies reject students with backlogs."),
    F("dsa_level", "DSA level (1 = beginner, 5 = advanced)", C, kind="scale", tip="Revise arrays, strings, hashing, recursion, trees, DP basics."),
    F("leetcode_solved", "LeetCode problems solved", C, hi=3000, dv=100, tip="Solve 2-3 LeetCode problems daily (easy first, then medium)."),
    F("codechef_rating", "CodeChef rating (0 if none)", C, hi=3500, tip="Join CodeChef Starters contests every week."),
    F("codeforces_rating", "Codeforces rating (0 if none)", C, hi=3500, tip="Try Codeforces Div 3 / Div 4 contests."),
    F("hackerrank_stars", "HackerRank stars (0-5)", C, tip="Earn HackerRank badges in Problem Solving, SQL and Java."),
    F("mini_projects", "Mini projects", P, hi=15, dv=2, tip="Build 2-3 small projects and put them on GitHub."),
    F("major_projects", "Major projects (full-stack / real-world)", P, hi=8, dv=1, tip="Build at least one major, deployed project with login, database and APIs."),
    F("internships", "Internships (incl. virtual)", P, hi=6, tip="Apply for internships or virtual internships (Forage, Internshala)."),
    F("certifications", "Certifications", P, hi=15, dv=1, tip="Do 2-3 relevant certificates (Java, SQL, AWS / Azure, NPTEL)."),
    F("hackathons", "Hackathons / competitions", P, hi=10, tip="Participate in hackathons - they build teamwork and projects fast."),
    F("tech_stack", "Main tech stack / career track", S, kind="sel", dv=STACKS[2], opts=[(s, s) for s in STACKS], tip=""),
    F("tech_known_count", "Technologies known (React, Spring, SQL, Git...)", S, lo=1, hi=30, dv=4, tip="Add the commonly asked tools: Git, REST APIs, SQL, one framework."),
    F("sql_level", "SQL / DBMS level (1-5)", S, kind="scale", tip="Practice joins, group by, subqueries and normalization."),
    F("cs_fundamentals", "CS fundamentals - OS, CN, OOP (1-5)", S, kind="scale", tip="Revise OS, DBMS, networks and OOP - they are asked in every interview."),
    F("aptitude", "Aptitude & reasoning (1-5)", S, kind="scale", tip="Practice quant and logical reasoning for 30 minutes daily."),
    F("communication", "Communication / English (1-5)", S, kind="scale", tip="Practice speaking, self-introduction and group discussions."),
    F("has_portfolio", "Personal portfolio website?", O, kind="yn", tip="Create a simple portfolio website and host it free (GitHub Pages / Netlify)."),
    F("github_active", "Active GitHub profile?", O, kind="yn", tip="Commit regularly and write a proper README for each project."),
    F("linkedin_profile", "LinkedIn profile ready?", O, kind="yn", tip="Create a LinkedIn profile and connect with recruiters and seniors."),
    F("ats_resume", "ATS-friendly one-page resume?", O, kind="yn", tip="Make a clean one-page, ATS-friendly resume."),
    F("deployed_project", "Any project deployed live?", O, kind="yn", tip="Deploy a project (Render, Vercel, AWS free tier) and share the link."),
    F("open_source", "Open-source contribution?", O, kind="yn", tip="Make a first contribution (good first issues on GitHub)."),
    F("mock_interviews", "Mock interviews given?", O, kind="yn", tip="Give mock interviews with friends or on Pramp / Interviewing.io."),
]
SECTIONS = {}
for f in FIELDS: SECTIONS.setdefault(f["sec"], []).append(f)
YN_COLS = [f["name"] for f in FIELDS if f["kind"] == "yn"]
COLS = [f["name"] for f in FIELDS]

# ---- Train from the Excel dataset ----
df = pd.read_excel("placement_data.xlsx", sheet_name="Data")
for c in YN_COLS: df[c] = df[c].astype(str).str.strip().str.lower().eq("yes").astype(int)
df["placed"] = df["placed"].astype(str).str.strip().str.lower().eq("yes").astype(int)
X, y = df[COLS], df["placed"]
model = Pipeline([("prep", ColumnTransformer([("c", OneHotEncoder(handle_unknown="ignore"), ["tech_stack"])], remainder=StandardScaler())),
                  ("clf", LogisticRegression(C=0.5, max_iter=2000))])
ACC = cross_val_score(model, X, y, cv=StratifiedKFold(5, shuffle=True, random_state=1)).mean() * 100
model.fit(X, y)
PLACED = df[df.placed == 1]

def suggestions(d):
    out = []
    for f in FIELDS:
        n, lab = f["name"], f["label"].split(" (")[0]
        if f["kind"] in ("num", "scale") and n != "tech_stack":
            med = PLACED[n].median()
            if f["hb"] and med > 0 and (med - d[n]) / med > 0.15:
                out.append(((med - d[n]) / med, f"{lab}: you have {d[n]:g}, placed students in the dataset typically have {med:g}. {f['tip']}"))
            elif not f["hb"] and f["kind"] == "num" and d[n] > med:
                out.append((0.6, f"{lab}: you have {d[n]:g}. {f['tip']}"))
        elif f["kind"] == "yn" and d[n] == 0:
            yes, no = df[df[n] == 1].placed.mean(), df[df[n] == 0].placed.mean()
            if yes - no > 0.1:
                out.append((yes - no, f"{lab}: {yes:.0%} of students who have it got placed vs {no:.0%} without it. {f['tip']}"))
    return [t for _, t in sorted(out, reverse=True)[:8]]

@app.route("/", methods=["GET", "POST"])
def index():
    v = {f["name"]: f["dv"] for f in FIELDS}
    result = None
    if request.method == "POST":
        v = {f["name"]: request.form.get(f["name"], f["dv"]) for f in FIELDS}
        d = {n: (x if n == "tech_stack" else float(x)) for n, x in v.items()}
        p = model.predict_proba(pd.DataFrame([d])[COLS])[0][1] * 100
        band, cls = ("High", "good") if p >= 70 else ("Medium", "mid") if p >= 40 else ("Low", "bad")
        same = df[df.tech_stack == d["tech_stack"]]
        result = dict(p=round(p, 1), band=band, cls=cls, tips=suggestions(d), stack=d["tech_stack"], n=len(same), placed=int(same.placed.sum()))
    return render_template("index.html", sections=SECTIONS, v=v, result=result, acc=round(ACC), total=len(df), placed=int(y.sum()))

if __name__ == "__main__":
    app.run(debug=True)
